<?php
include "functions.php";
include "connect.php";

rolefunc("Seller");

?>
<head>
  <link rel="stylesheet" href="css_styling.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>For Sellers...</title>
</head>
<body class="sellers_back">

<?php
logout_button();
back_button();
?>

<form method="GET">
            <input id="addProductButton" type="submit" name="addpbut" class="waving " value='ADD PRODUCT'>
                   
                    </input>

</form>

  <?php    
                 if(array_key_exists('addpbut',$_GET)){
                            add_product($conn);

                        }
    ?>

<?php
ajax_for_sellers($conn);
?>


</body>
</html>