<?php

session_start();

include ("connect.php");

function loginfunc($username,$password,$conn){
if(strlen($username)>0 && strlen($password)>0){
    $query = "SELECT * FROM Users WHERE username='$username' AND password='$password' limit 1" ;
    $result = mysqli_query($conn, $query);

    if(!$result){
       die( "Wrong data input, please retry");
    }
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
      }
    $user=mysqli_fetch_assoc($result);
    $_SESSION["user_role"]= $user["role"];
    $_SESSION["username"]=$user["username"];
    $_SESSION["user_id"]=$user["id"];
    $_SESSION["conf"]=$user["confirmed"];
    $_SESSION['totPrice']=0;
    if($result->num_rows!=1){
      die( "Wrong data input, please retry");
    }
    if($user["confirmed"]==0){
        die( "You have not been accepted yet");
    }
    
    header("Location: welcome.php");

}else{
echo "Please insert data of a valid length ";
}
}
function signupfunc($name,$surname,$username,$password,$email,$role,$conn){

  $query = "SELECT * FROM Users WHERE username='$username'" ;
  $res = mysqli_query($conn, $query);

  $user=mysqli_fetch_assoc($res);
    if($res->num_rows!=0){
      die( "A user with the same username already exists, please retry .");
    }

     $query  = "INSERT into `Users` (name,surname,username,password,email,role,confirmed)
    VALUES ('$name','$surname','$username','$password','$email','$role',0)";
        $result  = mysqli_query($conn, $query);


if (!$result) {
        die( "Wrong data input, please retry");
              }               
     if(mysqli_connect_errno()) {
         echo "Failed to connect to MySQL: " . mysqli_connect_error();
         exit();
       }
    //else result

   header("Location: index.php");
   
}

function logoutfunc(){
  $_SESSION['totPrice']=0;
  ?><script>
  window.location.replace("index.php");
  </script><?php
  die;
}


//Create a function that keeps a users role so that i can use it for access permission purposes
//$str is the role you want to be.
function rolefunc($str){
 
    $urole=$_SESSION["user_role"];

    if(!isset($urole)){
      ?><script>
      window.location.replace("index.php");
      </script><?php
    }else{//if user role is set

      if($urole==$str ){
        return;
      }else{
        ?><script>
        window.location.replace("permdenied.php");
        </script><?php
      } 
    }
       }


    function notauthentfunc(){
 
      $uname=$_SESSION["username"];

      if(!isset($uname)){
        ?><script>
        window.location.replace("index.php");
        </script><?php
      }else{//if user has already logged in
  
          return;
      }
  }

//function called in administration.php to print user table from phpmyadmin.
function print_user_table($conn){

// SQL query to select data from database
$sql = " SELECT * FROM Users ORDER BY id ASC ";
$result = mysqli_query($conn, $sql);

?>
<section>
        <h1>User Table</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>First Name </th>
                <th>Last Name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Confirmed</th>
               <!-- Buttons/Actions  --> 
               <th>Actions</th>

            </tr>
            <!-- PHP CODE TO FETCH DATA FROM ROWS -->
            <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- Fetching all data from all rows one by one -->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['surname'];?></td>
                <td><?php echo $rows['username'];?></td>
                <td><?php echo $rows['email'];?></td>
                <td><?php echo $rows['role'];?></td>
                <td><?php echo $rows['confirmed'];?></td>
                
                <form method=“GET“ class="forms">
                <?php
                $n=$rows['id'];
                echo "<td> 
                <div class='btn-group'>
                <input type='submit'class='btn btn-secondary' value='Confirm User' name='confbut_$n' >
                <input type='submit'class='btn btn-secondary' value= 'Edit User Information' name='editbut_$n' >
                <input type='submit'class='btn btn-secondary' value= 'Delete User' name='deletebut_$n'>
                </div>
                </td>";
                ?>
                </form>
                </tr>
                <?php
                if (array_key_exists('confbut_'.$n,$_GET)){
                  confirm_user($n,$conn);

                }
                if (array_key_exists('editbut_'.$n,$_GET)){
                    edit_user($n,$conn);

                }
                if (array_key_exists('deletebut_'.$n,$_GET)){
                  delete($n,$conn,'Users');
                }

                ?>  
                
            
            <?php
                }
              }
            ?>
    </section>

  
<?php
function ajax_print_user_table($conn){

  // SQL query to select data from database
  $sql = " SELECT * FROM Users ORDER BY id ASC ";
  $result = mysqli_query($conn, $sql);
  ?>
  
          <h1>User Table</h1>
          <!-- TABLE CONSTRUCTION -->
          <table>
              <tr>
                  <th>First Name </th>
                  <th>Last Name</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Role</th>
                  <th>Confirmed</th>
                 <!-- Buttons/Actions  --> 
                 <th>Actions</th>
  
              </tr>
              <!-- PHP CODE TO FETCH DATA FROM ROWS -->
              <?php

                  // LOOP TILL END OF DATA
                  while($rows=$result->fetch_assoc())
                  { $n=$rows['id'];
              ?>
              <tr id=<?php echo "row".$n ;?> >
                  <!-- Fetching all data from all rows one by one -->
                  <td><?php echo $rows['name'];?></td>
                  <td><?php echo $rows['surname'];?></td>
                  <td><?php echo $rows['username'];?></td>
                  <td><?php echo $rows['email'];?></td>
                  <td><?php echo $rows['role'];?></td>
                  <td id=<?php echo $n; ?>><?php echo $rows['confirmed'];?></td>
                  
                  <form method=“GET“>
                  <?php
                  
                  echo "<td> 
                  <div class='btn-group'>
                  <input type='submit'class='btn btn-secondary' value='Confirm User' onclick='ajax_confirm_user($n)'name='confbut_$n' >
                  <input type='submit'class='btn btn-secondary' value= 'Edit User Information' name='editbut_$n' >
                  <input type='submit'class='btn btn-secondary' value= 'Delete User' onclick='ajax_delete_user($n)' name='deletebut_$n'>
                  </div>
                  </td>";
                  ?>
                  </form>
                  </tr>
                  <?php
                
                  if (array_key_exists('editbut_'.$n,$_GET)){
                      edit_user($n,$conn);
                  }

                  }

                  ?>
    <script src="./jquery-3.6.1.js"></script>
    
    <script>
                
    function ajax_confirm_user(n){
      $.ajax({
        type:'POST',
        url:'./ajax_request.php',
        data:{func: 'confirm',id:n},
        success:function(data){
          $('#'+n).replaceWith('1');
         
        }

      });

     }
    
     function ajax_delete_user(n){
      $.ajax({
        type:'POST',
        url:'./ajax_request.php',
        data:{func: 'delete_users',id:n},
        success:function(data){
          $('#row'+n).detach();
         
        }

      });

     }

    </script>
                      

       <?php     

                }
              ?>
  
  
    
  <?php
function confirm_user($n,$conn){

  $query = "SELECT * FROM Users WHERE id='$n'" ;
  $res = mysqli_query($conn, $query);

  $user=mysqli_fetch_assoc($res);

  $_SESSION["conf"]=$user["confirmed"];
  if($user["confirmed"]==0){
    $q= "UPDATE Users SET confirmed = 1 WHERE id = '$n'";
    if(mysqli_query($conn,$q)){
      echo "Record was updated successfully.";
  } else {
      echo "ERROR: Could not able to execute $q. " 
       . mysqli_error($conn);
  }  
  }

}

//Code to edit user fields (the ones that are possible)
//We will first create a form (like the sign up form)
function edit_user($n,$conn){
  ?>
  <div class="forms">
  <form method="POST">
  <h3 style="color:#006600;">Edit User Information:</h3>
  First Name: <input type="text" name="name"><br>

  Last Name: <input type="text" name="surname"><br>

  Email: <input type="email" name="email"><br>

  Role: <input type="text" name="role"><br>
  
  <input type="submit" name="edit" class="button">
  
  </form>
  </div>
  


<?php
if(array_key_exists("edit", $_POST))
 {
    $name=$_POST['name'];
    $surname=$_POST['surname'];
    $email=$_POST['email'];
    $role=$_POST['role'];
    $update = "UPDATE Users SET name = '$name',surname = '$surname', email = '$email', role='$role' where id='$n'";
    mysqli_query($conn,$update);
     
 }
}

function delete($n,$conn,$nameoftable){
  $sql = "DELETE FROM $nameoftable WHERE id='$n'" ;

  mysqli_query($conn, $sql);
  
}


//Functions for the product sellers //

function for_sellers($conn){
// SQL query to select the correct products from database
$uname=$_SESSION["username"];
$sql = " SELECT * FROM Products WHERE sellername='$uname' ORDER BY id ASC ";
$result = mysqli_query($conn, $sql);
?>
<section>
        <h1>Product Table</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>Name </th>
                <th>Product Code</th>
                <th>Price</th>
                <th>Date of Withdrawal</th>
                <th>Category</th>
               <!-- Buttons/Actions  --> 
               <th>Actions</th>

            </tr>
            <!-- Php code to fetch data from rows -->
            <?php
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- Fetching all data from all rows one by one -->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['prodcode'];?></td>
                <td><?php echo $rows['price'];?></td>
                <td><?php echo $rows['dateofwithdrawal'];?></td>
                <td><?php echo $rows['category'];?></td>
                
                <form method=“GET“ class="forms">
                <?php
                $n=$rows['id'];
                echo "<td> 
                <div class='btn-group'>
                <input type='submit'class='btn btn-secondary' value= 'Edit Product Information' name='editpbut_$n' >
                <input type='submit'class='btn btn-secondary' value= 'Delete Product' name='deletepbut_$n'>
                </div>
                </td>";
                ?>
                </form>
                </tr>
                <?php
               
                if (array_key_exists('editpbut_'.$n,$_GET)){
                    edit_product($n,$conn);

                }
                if (array_key_exists('deletepbut_'.$n,$_GET)){
                    delete($n,$conn,'Products');
                }

              }
              ?> </section><?php
            }
 

            function ajax_for_sellers($conn){
              // SQL query to select the correct products from database
              $uname=$_SESSION["username"];
              $sql = " SELECT * FROM Products WHERE sellername='$uname' ORDER BY id ASC ";
              $result = mysqli_query($conn, $sql);
              ?>
              <section>
                      <h1>Product Table</h1>
                      <!-- TABLE CONSTRUCTION -->
                      <table>
                          <tr>
                              <th>Name </th>
                              <th>Product Code</th>
                              <th>Price</th>
                              <th>Date of Withdrawal</th>
                              <th>Category</th>
                             <!-- Buttons/Actions  --> 
                             <th>Actions</th>
              
                          </tr>
                          <!-- Php code to fetch data from rows -->
                          <?php
                              // LOOP TILL END OF DATA
                          while($rows=$result->fetch_assoc())
                          { $n=$rows['id'];
                          ?>
                          <tr id=<?php echo "row".$n ;?> >
                              <!-- Fetching all data from all rows one by one -->
                              <td><?php echo $rows['name'];?></td>
                              <td><?php echo $rows['prodcode'];?></td>
                              <td><?php echo $rows['price'];?></td>
                              <td><?php echo $rows['dateofwithdrawal'];?></td>
                              <td><?php echo $rows['category'];?></td>
                              
                              <form method=“GET“>
                              <?php
                              
                              echo "<td> 
                              <div class='btn-group'>
                              <input type='submit'class='btn btn-secondary' value= 'Edit Product Information' name='editpbut_$n' >
                              <input type='submit'class='btn btn-secondary' value= 'Delete Product' onclick='ajax_delete($n)' name = 'deletebut_$n'>
                              </div>
                              </td>";
                              ?>
                              </form>
                              </tr>
                              <?php
                             
                              if (array_key_exists('editpbut_'.$n,$_GET)){
                                  edit_product($n,$conn);
              
                              }
              
                            }
                            ?> 
                            <script src="./jquery-3.6.1.js"></script>
                            <script>
                            function ajax_delete(n){
          
                              $.ajax({
                                type:'POST',
                                url:'./ajax_request.php',
                                data:{func: 'delete_product_a',id:n},
                                success:function(data){
                                  $('#row'+n).detach();
                                
                                }

                              });
                            }
                            
                            </script>
                            </section>
                            
                            <?php
                          }
?>
<?php

function add_product($conn){

  ?>
  <form method="POST" class=form>
  <div class="forms">
  <h3 style="color:#006600;">Add Product:</h3>
  Product Name: <input type="text" name="name"><br>

  Product Code: <input type="text" name="prodcode"><br>

  Price: <input type="text" name="price"><br>

  Date of Withdrawal : <input type="date" name="dateofwithdrawal" value="<?php echo date('Y-m-d'); ?>" /><br>

  Category: <input type="text" name="category"><br>

  <input type="submit" name="add">
  
</form>
</div>
<?php
if(array_key_exists('add',$_POST))
 {
    $name=$_POST['name'];
    $prodcode=$_POST['prodcode'];
    $price=$_POST['price'];
    $dateofwithdrawal=$_POST['dateofwithdrawal'];
    $category=$_POST['category'];
    $sellername=$_SESSION['username'];

    $add= "INSERT INTO Products (id,name,prodcode,price ,dateofwithdrawal ,sellername ,category ) VALUES (NULL , '$name' , '$prodcode' , '$price' , '$dateofwithdrawal' ,'$sellername', '$category')";
    $sql = mysqli_query($conn,$add);
    
 }

}   

//Function to edit a product

function edit_product($n,$conn){
  ?>
  <div class="edit">
  <div class="forms">
  <form method="POST">
  <h3 style="color:#006600;">Edit Product Information:</h3>
  Name: <input type="text" name="name"><br>

  Product Code: <input type="text" name="prodcode"><br>

  Price: <input type="text" name="price"><br>

  Category: <input type="text" name="category"><br>
  
  <input type="submit" name="edit">
  
</form>
</div>
</div>
<?php
if(isset($_POST['edit']))
 {
  $name=$_POST['name'];
  $prodcode=$_POST['prodcode'];
  $price=$_POST['price'];
  $category=$_POST['category'];

    $update = "UPDATE Products SET name = '$name',prodcode = '$prodcode', price = '$price', category='$category' where id='$n'";
    $sql = mysqli_query($conn,$update);
    $result = mysqli_fetch_assoc($sql);
  
 }


}

function search_products($categoryofsearch,$searchbyvalue,$conn){

if($categoryofsearch == "category")
  $sql = "SELECT * FROM Products WHERE category='$searchbyvalue' ";

else if($categoryofsearch == "name")
  $sql = "SELECT * FROM Products WHERE name='$searchbyvalue' ";

else if($categoryofsearch == "prodcode")
  $sql = "SELECT * FROM Products WHERE prodcode='$searchbyvalue' ";

else if($categoryofsearch == "sellername")
  $sql = "SELECT * FROM Products WHERE sellername='$searchbyvalue' ";

else if($categoryofsearch == "price")
  $sql = "SELECT * FROM Products WHERE price='$searchbyvalue' ";

else if($categoryofsearch == "dateofwithdrawal")
  $sql = "SELECT * FROM Products WHERE dateofwithdrawal='$searchbyvalue' ";

  $result = mysqli_query($conn,$sql);
?>
<section>
<h1>Product Table</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>Name </th>
                <th>Product Code</th>
                <th>Price</th>
                <th>Date of Withdrawal</th>
                <th>Category</th>
               <!-- Buttons/Actions  --> 
               <th>Actions</th>
            </tr>
            <!-- Fetch data from all rows -->
            <?php
                //Loop through all the data
                echo($result->num_rows);
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- Fetching all data from all rows one by one -->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['prodcode'];?></td>
                <td><?php echo $rows['price'];?></td>
                <td><?php echo $rows['dateofwithdrawal'];?></td>
                <td><?php echo $rows['sellername'];?></td>
                <td><?php echo $rows['category'];?></td>
                
                <form method="POST">
                <?php
                $n=$rows['id'];
                echo "<td> 
                <div class='btn-group'>
                <input type='submit'class='btn btn-secondary' value='Add To Cart' name='addtocartbut_$n' >
                </div>
                </td>";
                ?>
                </form>
                </tr>
                <?php
                if (array_key_exists('addtocartbut_'.$n,$_POST)){
                  add_to_cart($n,$conn);
                }
                }

            ?>
    </section>    
<?php

            }




function print_products($conn){
// SQL query to select data from database
$sql = " SELECT * FROM Products ORDER BY id ASC ";
$result = mysqli_query($conn, $sql);
?>
<section>
        <h1>Product Table</h1>
        <!-- TABLE CONSTRUCTION -->
        <table>
            <tr>
                <th>Product Name</th>
                <th>Product Code</th>
                <th>Price</th>
                <th>Date of Withdrawal</th>
                <th>Seller Name</th>
                <th>Category</th>
               <!-- Buttons/Actions  --> 
               <th>Actions</th>
            </tr>
            <!-- Fetch data from all rows -->
            <?php
                //Loop through all the data
                while($rows=$result->fetch_assoc())
                {
            ?>
            <tr>
                <!-- Fetching all data from all rows one by one -->
                <td><?php echo $rows['name'];?></td>
                <td><?php echo $rows['prodcode'];?></td>
                <td><?php echo $rows['price'];?></td>
                <td><?php echo $rows['dateofwithdrawal'];?></td>
                <td><?php echo $rows['sellername'];?></td>
                <td><?php echo $rows['category'];?></td>
                
              <form method="POST">
                <?php
                $n=$rows['id'];
                echo "<td> 
                <div class='btn-group'>
                <input type='submit'class='btn btn-secondary' value='Add To Cart' name='addtocartbut_$n' >
                </div>
                </td>";
                ?>
              </form>
                </tr>
                <?php
                if (array_key_exists('addtocartbut_'.$n,$_POST)){
                  add_to_cart($n,$conn);
                }
                ?>  
            <?php
                }
              }
            ?>
    </section>

<?php


function add_to_cart($n,$conn){

  $user_id=$_SESSION["user_id"];

  $add_to_cart= "INSERT INTO Carts (id,userid,productid,dateofinsertion ) VALUES (NULL , '$user_id' , '$n' , CURRENT_TIMESTAMP )";

  $res = mysqli_query($conn, $add_to_cart);
  
}


function print_cart($conn){
  // SQL query to select data from database
  $id=$_SESSION["user_id"];
  $sql = " SELECT * FROM Carts  WHERE userid=$id ORDER BY id ASC ";
  $result = mysqli_query($conn, $sql);
  ?>
  <section>
          <h1>Cart</h1>
          <table>
              <tr>
                  <th>Product ID</th>
                  <th>Date of Insertion</th>
                 <!-- Buttons/Actions  --> 
                 <th>Actions</th>
              </tr>
              <!-- Fetch data from all rows -->
              <?php
                  //Loop through all the data
                  while($rows=$result->fetch_assoc())
                  {
              ?>
              <tr>
                  <!-- Fetching all data from all rows one by one -->
                  <td><?php echo $rows['productid'];?></td>
                  <td><?php echo $rows['dateofinsertion'];?></td>

                <form method=“GET“>
                  <?php
                  $n=$rows['id'];
                  $prod_id=$rows['productid'];
                  $pr = "SELECT price FROM Products WHERE id=$prod_id";
                  $prresult = mysqli_query($conn, $pr);
                  $prrows=$prresult->fetch_assoc();
                  
                  $_SESSION['totPrice']=$_SESSION['totPrice'] + $prrows['price'];
                  
                  echo "<td> 
                  <div class='btn-group'>
                  <input type='submit'class='btn btn-secondary' value='Delete From Cart' name='deletefromcartbut_$n' >
                  </div>
                  </td>";
                  ?>
                </form>
                  </tr>
                  <?php
                  if (array_key_exists('deletefromcartbut_'.$n,$_GET)){
                    delete_from_cart($n,$conn, $prrows['price']);
                  }

                  ?>  
              <?php
                  }
                  echo "Total Price : ".$_SESSION['totPrice'];
                }
              ?>
      </section>
  
  <?php

function ajax_print_cart($conn){
  $_SESSION['totPrice']=0;
  // SQL query to select data from database
  $id=$_SESSION["user_id"];
  $sql = " SELECT * FROM Carts  WHERE userid=$id ORDER BY id ASC ";
  $result = mysqli_query($conn, $sql);
  ?>

          <h1>Cart</h1>
          <table>
              <tr>
                  <th>Product ID</th>
                  <th>Date of Insertion</th>
                 <!-- Buttons/Actions  --> 
                 <th>Actions</th>
              </tr>
              <!-- Fetch data from all rows -->
              <?php
                  //Loop through all the data
                  while($rows=$result->fetch_assoc())
                  {$n=$rows['id'];
                    $prod_id=$rows['productid'];
                    $pr = "SELECT price FROM Products WHERE id=$prod_id";
                    $prresult = mysqli_query($conn, $pr);
                    $prrows=$prresult->fetch_assoc();
                    $prrows_price=$prrows['price'];
                    
                    $_SESSION['totPrice']=$_SESSION['totPrice'] + $prrows_price;
              ?>
              <tr id=<?php echo "row".$n ;?>>
                  <!-- Fetching all data from all rows one by one -->
                  <td><?php echo $rows['productid'];?></td>
                  <td><?php echo $rows['dateofinsertion'];?></td>

                <form method=“GET“>
                  <?php

                  echo "<td> 
                  <div class='btn-group'>
                  <input type='submit'class='btn btn-secondary' value='Delete From Cart' onclick='ajax_delete_from_cart($n,$prrows_price)' >
                  </div>
                  </td>";
                  ?>
                  </form>
                  </tr>
                   
              <?php
                  }
                  ?>
                  <script src="./jquery-3.6.1.js"></script>
    
                  <script>
                      function ajax_delete_from_cart(n,prrows){
                        $.ajax({
                          type:'POST',
                          url:'./ajax_request.php',
                          data:{func: 'delete_fromcart',id:n,prod:prrows},
                          success:function(data){
                            $('#row'+n).detach();
                          }
                  
                        });
                  
                      }
                  
                  </script>
                  <?php
                  echo "Total Price : ".$_SESSION['totPrice'];
                }
              ?>

  
  <?php

function delete_from_cart($n,$conn,$product){
$sql = "DELETE FROM Carts WHERE id='$n'" ;
mysqli_query($conn, $sql);
$_SESSION['totPrice']=$_SESSION['totPrice']-$product;

}

function back_button(){
?>
<form method="POST" >
            <button id="backButton" type="submit" name="backbut" class="waving">
                   Back 
         </button>
</form>
  <?php    
                 if(array_key_exists('backbut',$_POST)){
                  ?><script>
                  window.location.replace("welcome.php");
                  </script><?php
                        }
  
}
?>

<?php 
function logout_button(){
?>
<div class = "button_logout">
<form method="GET">
    <button id="logoutButton" type="submit" name="logoutbut" >
     LOG OUT 
    </button> 
</form>
            
 <?php    
    echo ("(".$_SESSION["user_role"]."), ".$_SESSION["username"]);
        if(array_key_exists('logoutbut',$_GET)){
             logoutfunc();
            }
?>
  </div>
  <?php
          }


function products_to_cart(){
?>
<form method="POST">
<div class="forms">
            <button id="prodtocartButton" type="submit" name="prodtocartbut" class="waving">
                   Go To Cart
         </button>
</form>
</div>
  <?php    
                 if(array_key_exists('prodtocartbut',$_POST)){
                  ?><script>
                  window.location.replace("cart.php");
                  </script><?php
                        }
  
}
