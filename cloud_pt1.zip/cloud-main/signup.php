<!DOCTYPE html>
<html>
    <head>
        <title> Registration Page</title>
            <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
            <link rel="stylesheet" type="text/css" href="css_styling.css">

    </head>
    <body class="index_back">
        <div class="container" >
            <div class="row col-md-6 col-md-offset-3">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center">
                        <h1> Registration Form </h1>
                    </div>
                    <div class="panel-body">
                        <form method="post">
                           <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" id="name" name="name"/>
                           </div> 

                           <div class="form-group">
                            <label for="surname">Surname</label>
                            <input type="text" class="form-control" id="surname" name="surname"/>
                           </div> 

                           <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username"/>
                           </div> 
                           <div class="form-group">
                            <label for="password">Password</label>
                            <input type="text" class="form-control" id="password" name="password"/>
                           </div> 
                           <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" id="email" name="email"/>
                           </div> 
                           
                           <div class="form-group">
                            <label for="role">Role</label>
                           <div>
                            <label for="admin" class="radio-inline"><input type="radio" name="role" value="Admin" id="admin">Admin</label>
                            <label for="prodseller" class="radio-inline"><input type="radio" name="role" value="Seller" id="prodseller">Product Seller</label>
                            <label for="user" class="radio-inline"><input type="radio" name="role" value="User" id="user">User</label>
                           </div> 
                           </div>
                           <input type="submit" class="button" name="submit">
                        </form>
                        
                    </div>
                    <?php
                            include "./connect.php"; 
                            include "./functions.php";
                        
                            $name=$_POST['name'];
                            $surname=$_POST['surname'];
                            $username=$_POST['username'];
                            $password=$_POST['password'];
                            $email=$_POST['email'];
                            $role=$_POST['role'];
                            echo $role;
                            
                        if (array_key_exists("submit", $_POST)) {
                            signupfunc($name,$surname,$username,$password,$email,$role,$conn);
                        }

    ?>
                    <div class="panel-footer text-right">
                        <small>&copy; MyEshop.gr</small>
                    </div>
                </div>
            </div>
        </div>
</body>
</html>

