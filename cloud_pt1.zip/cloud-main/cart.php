<?php
include "functions.php";
include "connect.php";

rolefunc("User");

?>
<head>
  <link rel="stylesheet" href="css_styling.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cart</title>
</head>
<body class="user_back">
<?php
logout_button();
back_button();
?>

<?php
ajax_print_cart($conn);
?>

</body>
</html>