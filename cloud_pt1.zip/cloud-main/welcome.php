<!DOCTYPE html>
<?php
session_start();
include "functions.php";

notauthentfunc();
?>
<html lang="en">
<head>
    <link rel="stylesheet" href="css_styling.css">


    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome !</title>



        <title>Navigation Menu</title>
        <link rel="stylesheet" href="/style.css" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script type="text/javascript">
		$(document).ready(function(){
			$('#mainsection').click(function(){
				  $('#menulists').slideToggle(200);
			});
		});
		</script>
    </head>
    <body>
    <body class="welcome_back">
        <div id="wrapper">
        <div class="mainsection" id="mainsection">
            <div class="shortmenu">
                <img src="menu.png"/>
            </div>
		</div>
        <div class="menu-lists" id="menulists" >
            <ul>
                <li><a href="products.php">Products </a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="seller.php">For Product Sellers...</a></li>
                <li><a href="administration.php">Administration</a></li>
            </ul>
        </div>
        </div>
 <?php
logout_button();

?>
    </body>
</html>
 


