<?php


// Database connection 
$conn =mysqli_connect('localhost','root','','coffeeshop');

if(!$conn){
    die('Connection to database failed : ');
}



?>