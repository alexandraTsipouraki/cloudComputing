<html>
<head>
<meta charset="utf-8">
<title>Permission Denied</title>

<script type="text/javascript">
alert("You are not allowed to enter this page ! We are redirecting you to the main menu.")

window.location.replace("welcome.php");
</script>
</head>
<body>
</body>
</html>
