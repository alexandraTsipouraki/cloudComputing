<?php
include "functions.php";
include "connect.php";

rolefunc("User");

// Create a form that shows all the search options as an enumeration
?>
<html>
<head>
  <link rel="stylesheet" href="css_styling.css">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products </title>
</head>
    <body class="user_back">
        <div class="container" >
            <div class="row col-md-6 col-md-offset-3">
                <div class="panel panel-primary">
                    <div class="panel-heading text-center">
                        <h1> Search for products : </h1>
                    </div>
                    <div class="panel-body">
                        <form method="post" class ="form-group">
            <div class="form-group">
                            <label for="search">What are you looking for ?</label>
                            <input type="text" class="form-control" name="searchbyvalue"/>

                            <label for="searchby">Search by : </label><br>
                    <select name="search">
                            <option value="name" >Product Name</option><br>
                            <option value="prodcode" >Product Code</option><br>
                            <option value="category" >Category</option><br>
                            <option value="sellername" >Seller Name</option><br>
                            <option value="price" >Price</option><br>
                            <option value="dateofwithdrawal">Date of Withdrawal</option><br>
                    </select>
                           </div> 
                           </div>
                           <input type="submit" class="btn btn-primary" name="submitForm" value="Search"/>
                        </form>
                    </div>
                    <?php
 
                        if (array_key_exists("submitForm", $_POST)) {
                            search_products($_POST["search"],$_POST["searchbyvalue"],$conn);
                        }else{
                            print_products($conn);
                        }

                ?>

<?php
logout_button();
back_button();
products_to_cart();
?>
            
            </body>
            </html>