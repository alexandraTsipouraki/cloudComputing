<?php
include "functions.php";
include "connect.php";

if($_POST['func']=='confirm'){
    confirm_user($_POST['id'],$conn);
}
else if($_POST['func']=='delete_users'){
    delete($_POST['id'],$conn,'Users');
}
else if($_POST['func']=='delete_fromcart'){
    delete_from_cart($_POST['id'],$conn,$_POST['prod']);
}
else if($_POST['func']=='delete_product_a'){
    echo("inside");
    delete($_POST['id'],$conn,'Products');
}
?>