
<!DOCTYPE html>
<html>

    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to MyLocalCoffeeShop.gr ! </title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css_styling.css">

<!-- Code for buttons -->

</head>
<body class="index_back">
    <?php
include ("connect.php");
include ("functions.php");
?>
     <div class="container">
        <div class="row col-md-3 col-md-offset-8">
            <div class="panel card-primary">
                <div class="panel-heading">
                    <h1>Login form</h1>
                </div> 
                <div class="panel-body">
                    <form name="index_form" method=“GET“>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" name="username"/>
                        </div>
                        <div class="form-group">
                            <label for="password">Password </label>
                            <input type="password" class="form-control" id="password" name="password"/>
                        </div>
        
                 <div>
                    <button id="loginButton" type="submit" name="loginbut" class="waving">
                        LOGIN
                    </button>
                    <button id="signupButton" type="submit" name="signupbut" class="btn-2">
                        SIGN UP
                    </button>
                </div>
                    </form>
                    <?php

                        if(array_key_exists('loginbut',$_GET)){
                            
                            loginfunc($_GET["username"],$_GET["password"],$conn);
                        }

                        if(array_key_exists('signupbut',$_GET)){
                        
                            header("Location: signup.php");
                        }

                    ?>
                </div>
                <div class="panel-footer text-right">
                   <small> &copy; MyLocalCoffeeShop.gr</small>
                </div>
            </div>
    </div>   
    </body>
</html>

