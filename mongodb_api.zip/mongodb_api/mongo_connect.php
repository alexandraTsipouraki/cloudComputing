<?php
    require '../config/vendor/autoload.php';
    $conn = new MongoDB\Client("mongodb://root:root@mongo:27017");
    $db = $conn->mls_db;

    $products = $db->products;
    $cart = $db->cart;

?>