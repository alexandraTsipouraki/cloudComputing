<?php
header('Content-Type: application/json');
include("../mongo_connection.php");

if($con){
    $data = json_decode(file_get_contents('php://input'), true);
    $id=$data['_id'];
    $id=new MongoDB\BSON\ObjectId($id);
    $category=$data['category'];
    $new_val=$data['new_val'];
    $answer = $products->updateOne(['_id'=>$id], ['$set'=>[$category=>$new_val]]);
    die; 
}

?>