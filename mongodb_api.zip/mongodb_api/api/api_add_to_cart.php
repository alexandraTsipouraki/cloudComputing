<?php
    include("../mongo_connect.php");
    header('Content-Type: application/json');

    if($conn){
        $data = json_decode(file_get_contents('php://input'), true);
        $userid = $data['userid'];
        $prodcode=$data['prodcode'];
        $name=$data['name'];
        $price=$data['price'];
        //$dateofinsertion=$data['dateofinsertion'];
        $filter = [];
        $fields = array(
            'userid'=>$userid,
            'prodcode'=>$prodcode,
            'name'=>$name,
            'price'=>$price,
            'dateofinsertion'=>date("Y-m-d")
        );
        $cart->insertOne($fields);
        
        die;
    }

   

?>