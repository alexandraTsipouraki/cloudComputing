<?php
header('Content-Type: application/json');

include("../mongo_connect.php");

if($conn){
        $ans = $products->find()->toArray();
        echo json_encode($ans, JSON_PRETTY_PRINT) ;            
        die;
    
}