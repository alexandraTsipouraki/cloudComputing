<?php
    include("../mongo_connect.php");
    header('Content-Type: application/json');

    if($conn){
        $data = json_decode(file_get_contents('php://input'), true);
        $name = $data['name'];
        $prodcode=$data['prodcode'];
        $dateofwithdrawal=$data['dateofwithdrawal'];
        $price=$data['price'];
        $sellername=$data['sellername'];
        $category=$data['category'];
        $filter = [];
        $fields = array(
            'name'=>$name,
            'prodcode'=>$prodcode,
            'dateofwithdrawal'=>$dateofwithdrawal,
            'price'=>$price,
            'sellername'=>$sellername,
            'category'=>$category
        );
        $products->insertOne($fields);
        
        die;
    }

   

?>