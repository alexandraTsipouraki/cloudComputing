<?php
header('Content-Type: application/json');
include("../mongo_connect.php");

if($conn){ 
    if(isset($_GET['category'] )){
        $val=$_GET['category'];
        $ans = $products->find(['category'=>strval($val)], [])->toArray();
        echo json_encode($ans);
        die;
    }
    else if(isset($_GET['name'] )){
        $val=$_GET['name'];
        $ans = $products->find(['name'=>strval($val)], [])->toArray();
        echo json_encode($ans);
        die;
    }
    else if(isset($_GET['prodcode'] )){
        $val=$_GET['prodcode'];
        $ans = $products->find(['prodcode'=>strval($val)], [])->toArray();
        echo json_encode($ans);
        die;
    }
    else if(isset($_GET['sellername'] )){
        $val=$_GET['sellername'];
        $ans = $products->find(['sellername'=>strval($val)], [])->toArray();
        echo json_encode($ans);
        die;
    }
    else if(isset($_GET['dateofwithdrawal'] )){
        $val=$_GET['dateofwithdrawal'];
        $ans = $products->find(['dateofwithdrawal'=>strval($val)], [])->toArray();
        echo json_encode($ans);
        die;
    }
    

}
