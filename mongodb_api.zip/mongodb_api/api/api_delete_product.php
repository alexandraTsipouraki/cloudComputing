<?php
include("../mongo_connect.php");
if($conn){
    if(isset($_GET['id'])){
        $id=$_GET['id'];
        $id=new MongoDB\BSON\ObjectId($id);
        $ans = $products->deleteOne(['_id'=>($id)]);
        echo json_encode($ans);
        die;
    }
}

?>