<?php
header('Content-Type: application/json');
include ("../mongo_connect.php");
if($conn){
    if(isset($_GET['userid'])){
        $userid=$_GET['userid'];
        $resp=$cart->find(['userid'=>strval($userid)],[])->toArray();
        echo json_encode($resp);
        die;
    }
}

?>