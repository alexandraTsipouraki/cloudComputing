<?php
header('Content-Type: application/json');
include("../mongo_connect.php");

if($conn){
    if(isset($_GET['seller_email'])){
        $email=$_GET['seller_email'];
        $ans = $products->find(['sellername'=>strval($email)],[])->toArray();
        echo json_encode($ans);            
        die;
    }
}
?>