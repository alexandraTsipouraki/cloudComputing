<?php
include("../mongo_connect.php");
if($conn){
    if(isset($_GET['_id'])){
        $id=$_GET['_id'];
        $id=new MongoDB\BSON\ObjectId($id);
        $ans = $cart->deleteOne(['_id'=>$id]);
        echo json_encode("deleted");
        die;
    }
}

?>